@tool
extends Node2D
class_name SwingPlatform
@onready var platform: AnimatableSolidObject = $platform

@export var preview: bool = false
@export_range(-360,360,0.1, "degrees") var magnitude: float = 180.0
@export var period: float = 0.6
@export_range(-360,360,0.1, "degrees") var orientation_angle: float = 90.0

@export var chain_texture: Texture2D
@export var length: int = 5
var angle: float = 0
var old_position: Vector2

var elapsed = 0
func _process(delta: float) -> void:
	if !preview and Engine.is_editor_hint():
		angle = orientation_angle
		update_platform(delta)
		return
	angle = (sin(elapsed / period)*magnitude) + orientation_angle
	
	update_platform(delta)
	
	elapsed += delta

func update_platform(_delta: float) -> void:
	old_position = position
	
	queue_redraw()
	var v1 = Vector2((length-0.5)*16,0)
	var v2 = round(v1.rotated(deg_to_rad(angle)))
	if platform:
		platform.position = v2 + Vector2.RIGHT

func _draw() -> void:
	for i in range(length):
		var v1 = Vector2(i*16,0)
		var v2 = round(v1.rotated(deg_to_rad(angle)))
		draw_texture(chain_texture, v2 - Vector2(8,8))
