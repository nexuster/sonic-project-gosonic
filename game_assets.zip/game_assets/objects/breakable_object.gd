extends SolidObject
class_name BreakableObject

func _ready() -> void:
	modulate.a = 1.0
	player_ground_collision.connect(_on_player_collide)

func _on_player_collide(player: Player) -> void:
	if player.is_jumping:
		player.velocity.y = -224.0
		queue_free()
