extends CharacterBody2D
class_name Enemy
signal exploded

const explosion = preload("res://objects/particles/Explosion0.tscn")
@onready var state_machine: StateMachine = $StateMachine

@export var sprite2d: Sprite2D
@export var anim_sprite: AnimatedSprite2D
@export var interaction: Area2D
@export var audio: AudioStreamPlayer

var sprite: Node

var already_exploded = false

func _ready() -> void:
	if sprite2d:
		sprite = sprite2d
	else:
		sprite = anim_sprite
	interaction.area_entered.connect(collided)

func collided(area: Area2D) -> void:
	var v = area.get_parent()
	if v:
		if self is Danger:
			v.hurt("danger", self)
		var attack_valid = false
		if v is InstaShield:
			attack_valid = true
		if v is FlameShield:
			attack_valid = v.attacking
		if v is Player:
			attack_valid = v.is_rolling or v.is_jumping
		if attack_valid:
			if v is Shield:
				explode(v.shield_user)
			elif v is Player:
				explode(v)
		else:
			if v is Player:
				v.hurt("badnik", self)

func explode(player: Player) -> void:
	if already_exploded:
		return
	already_exploded = true
	exploded.emit()
	if player.position.y < position.y:
		player.velocity.y *= -1
	if sprite:
		sprite.visible = false
	if interaction:
		interaction.monitorable = false
		interaction.monitoring = false
	
	var new_explosion: Particle = explosion.instantiate()
	add_child(new_explosion)
	new_explosion.position = Vector2.ZERO
	
	new_explosion.play()
	if audio:
		audio.play()
		await audio.finished
	else:
		await new_explosion.animation_player.animation_finished
	
	queue_free()
	

func change_state(state: StringName):
	state_machine.change_state(state.to_lower())
