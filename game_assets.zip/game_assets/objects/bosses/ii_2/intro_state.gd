extends EnemyState
@export var intro_tween: TweenResource
@onready var cam: PlayerCamera

var sprite: AnimatedSprite2D

func enter(enemy: Enemy) -> void:
	cam = Global.camera
	var vprect: Rect2 = get_viewport_rect()
	global_position = cam.global_position + Vector2(vprect.size.x, 32.0)
	
	sprite = enemy.find_child("AnimatedSprite2D")
	
	var tween: Tween = create_tween(
		).set_ease(intro_tween.easing).set_trans(intro_tween.transition)
		
	var new_pos: float = cam.global_position.x + vprect.size.x / 2
	tween.tween_property(enemy, "position:x", new_pos, intro_tween.duration)
	
	await tween.finished
	
	enemy.change_state("hover")

func animate(_enemy: Enemy, _delta: float) -> void:
	sprite.play("burner")
