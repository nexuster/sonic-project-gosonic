extends EnemyState

var player: Player

func enter(_enemy: Enemy) -> void:
	player = Global.player
