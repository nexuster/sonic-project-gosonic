extends Node2D
class_name StateMachine

@export var default_state: EnemyState
@export var screen: VisibleOnScreenNotifier2D
var states: Dictionary[StringName, EnemyState] = {}

var current_state: EnemyState
var last_state: EnemyState
var enemy: Enemy

func _ready() -> void:
	enemy = get_parent()
	
	for i in get_children():
		if i is EnemyState:
			states[i.name.to_lower()] = i
			i.process_mode = Node.PROCESS_MODE_DISABLED
	
	if default_state:
		default_state._enter(get_parent())
		current_state = default_state
		current_state.process_mode = Node.PROCESS_MODE_PAUSABLE

func _process(delta: float) -> void:
	if current_state and enemy and screen.is_on_screen():
		current_state._animate(enemy, delta)

func _physics_process(delta: float) -> void:
	if current_state and enemy and screen.is_on_screen():
		current_state._step(enemy, delta)

func change_state(state: StringName) -> void:
	if state.to_lower() == current_state.name.to_lower():
		return
	if current_state:
		current_state._exit(enemy)
	
	last_state = current_state
	var new_state = states[state.to_lower()]
	if !new_state:
		return
	queue_enter(new_state)
	current_state = new_state

func queue_enter(state: EnemyState):
	#state._enter(enemy)
	if screen.is_on_screen():
		state._enter(enemy)
	else:
		await screen.screen_entered
		state._enter(enemy)
