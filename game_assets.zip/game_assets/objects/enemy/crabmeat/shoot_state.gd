extends EnemyState
class_name CrabmeatShootState
var shot: float = false

func _enter(enemy: Enemy) -> void:
	var e = enemy as Crabmeat
	await get_tree().create_timer(1.0).timeout
	e.direction *= -1
	e.change_state("patrol")
	shot = false

func _step(enemy: Enemy, _delta: float) -> void:
	enemy.move_and_slide()

func _animate(enemy: Enemy, _delta: float) -> void:
	var sprite = enemy.sprite as AnimatedSprite2D
	sprite.play("shoot")
	if sprite.frame == 3 and !shot:
		shot = true
		spawn_projectiles(enemy)

func spawn_projectiles(crab: Crabmeat) -> void:
	var pj_markers: Array[Marker2D] = [
		crab.spawn_1,
		crab.spawn_2
	]
	var dir: Array[int] = [
		-1, 1
	]
	
	var i: int = 0
	for marker: Marker2D in pj_markers:
		var pj_scene: PackedScene = load(
			"res://game_assets/objects/enemy/falling_projectile.tscn"
		)
		var pj: Projectile = pj_scene.instantiate()
		crab.get_parent().add_child(pj)
		pj.global_position = marker.global_position
		pj.direction = Vector2i(dir[i], 1)
		
		pj.boost()
		i += 1
