extends EnemyState
class_name CrabmeatPatrolState

func _enter(enemy: Enemy) -> void:
	await get_tree().create_timer(128.0/60.0).timeout
	enemy.change_state("wait")

func _step(enemy: Enemy, _delta: float) -> void:
	enemy.velocity.x = enemy.speed * enemy.direction
	enemy.move_and_slide()
	
	var crab = enemy as Crabmeat
	if ((crab.direction < 0 and !crab.left.is_colliding()) or
	(crab.direction > 0 and !crab.right.is_colliding())):
		enemy.change_state("wait")

## Regular proccess
func _animate(enemy: Enemy, _delta: float) -> void:
	var sprite = enemy.sprite as AnimatedSprite2D
	sprite.play("default")
