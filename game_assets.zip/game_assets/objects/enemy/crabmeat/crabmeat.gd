extends Enemy
class_name Crabmeat
@onready var screen = $VisibleOnScreenNotifier2D
@onready var left: RayCast2D = $left_edge
@onready var right: RayCast2D = $right_edge

@export var spawn_1: Marker2D
@export var spawn_2: Marker2D


@export var speed: float = 128.0/256.0 * 60.0
var direction = -1


func _process(delta: float) -> void:
	$Label.text = $StateMachine.current_state.name.to_lower()
