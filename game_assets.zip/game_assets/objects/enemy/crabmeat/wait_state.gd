extends EnemyState
class_name CrabmeatWaitState

func _enter(enemy: Enemy) -> void:
	enemy.velocity.x = 0
	await get_tree().create_timer(90.0/60.0).timeout
	enemy.change_state("shoot")

func _step(enemy: Enemy, _delta: float) -> void:
	enemy.move_and_slide()

func _animate(enemy: Enemy, _delta: float) -> void:
	var sprite = enemy.sprite as AnimatedSprite2D
	sprite.play("wait")
