extends Node2D
class_name EnemyState

## Called when the state is activated.
func _enter(enemy: Enemy) -> void:
	pass

## Called when the state was active, and another state is activated.
func _exit(enemy: Enemy) -> void:
	pass

## Physics proccess
func _step(enemy: Enemy, _delta: float) -> void:
	pass

## Regular proccess
func _animate(enemy: Enemy, _delta: float) -> void:
	pass
