extends Danger
class_name Projectile

@export var screen: VisibleOnScreenNotifier2D

var direction: Vector2i = Vector2i(1, -1)
var speed := Vector2(60.0, -4.0*60.0)
var gravity = 56.0/256.0 * 60

static func new_projectile(
		dir := Vector2i(1, 1), 
		spd := Vector2(60.0, 4.0*60.0)
		) -> Projectile:
	var nw: Projectile = new()
	nw.direction = dir
	nw.speed = spd
	return nw

func _ready() -> void:
	interaction.area_entered.connect(func (area: Area2D):
		var player = area.get_parent()
		if player is Player:
			player.hurt("danger", self)
	)
	boost()
	await screen.screen_exited
	queue_free()

func boost() -> void:
	velocity = speed * Vector2(direction)

func _physics_process(_delta: float) -> void:
	velocity.y += gravity

	move_and_slide()
