@tool
extends Enemy
class_name Orbinaut

@onready var spikeballs: Node2D = $spikeballs
@onready var screen: VisibleOnScreenNotifier2D = $VisibleOnScreenNotifier2D

@export_range(0,100.0,0.1, "exp", "suffix:px/s") var speed: float = 12.5

var elapsed = 0
var direction = 1

func _ready() -> void:
	exploded.connect(remove_danger)

func _process(delta: float) -> void:
	if !Engine.is_editor_hint():
		if !screen.is_on_screen():
			return
	var hpi: float = PI / 2
	
	if !Engine.is_editor_hint():
		var player: Player = Player.most_recent_player
		if player:
			direction = sign(player.position.x-position.x)
			var dist = abs(player.position.x-position.x)
			var movement_speed = delta * speed
			
			var player_facing = 1 if !player.skin.flip_h else -1
			
			if player_facing == direction:
				if dist > movement_speed * 2:
					position.x += movement_speed * direction
	
	var i: int = 0
	for v: Danger in spikeballs.get_children():
		v.position = Vector2(
			direction * sin((elapsed * 120 * delta) + (i * hpi)) * 12,
			cos((elapsed * 120 * delta) + (i * hpi)) * 12
		)
		
		i += 1
	elapsed += delta
	elapsed = fmod(elapsed, PI*2)

func remove_danger() -> void:
	for i in spikeballs.get_children():
		i.queue_free()
