extends Enemy
class_name Danger

func _ready() -> void:
	interaction.area_entered.connect(_interacted)

func _interacted(area: Area2D):
	var player = area.get_parent()
	if player is Player:
		player.hurt("danger", self)
