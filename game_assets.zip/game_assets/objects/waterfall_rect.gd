@tool
extends TextureRect
class_name Waterfall

@onready var fill: TextureRect = $fill
@onready var fill2: TextureRect = $fill2

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$AnimationPlayer.play("default")
	custom_minimum_size = Vector2.ONE * 32
	
	set_notify_local_transform(true)
	set_notify_transform(true)
	
	update_minimum_size()

func _notification(what: int) -> void:
	if what == 2000 or what == 35:
		update_rect()

func update_rect():
	update_minimum_size()
	
	fill.size = size + Vector2.UP * 16.0
	fill2.size = Vector2(size.x, 16.0)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
