extends Area2D
class_name PlayerTunnelLock

var hit: bool = false
func _physics_process(_delta: float) -> void:
	var player = find_overlapping_player()
	if player:
		if player.state_machine.current_state != "Rolling":
			player.change_state("Rolling")
		
		if is_zero_approx(player.velocity.x):
			player.velocity.x = 120.0
			if player.state_machine.current_state != "Rolling":
				player.change_state("Rolling")
			
		player.lock_controls(0.1)

func find_overlapping_player() -> Player:
	var ovl: Array[Area2D] = get_overlapping_areas()
	for i:Area2D in ovl:
		var body: = i.get_parent()
		if body is Player:
			return body
	return
