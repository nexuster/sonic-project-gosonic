extends Node2D
class_name Spinner
@onready var animation: AnimationPlayer = $AnimationPlayer
@onready var interaction: Area2D = $INTERACTION
@onready var stream: AudioStreamPlayer = $SpringAudio

@export var SPEED_BOOST: float = 16.0*60.0

var active: bool = false

func _ready() -> void:
	animation.play("idle")

func _physics_process(_delta: float) -> void:
	var player: Player = find_overlapping_player()
	if player:
		if player.is_grounded() and not active:
			active = true
			player.velocity.x = SPEED_BOOST
			stream.play()
	else:
		active = false

func find_overlapping_player() -> Player:
	var ovl: Array[Area2D] = interaction.get_overlapping_areas()
	for i:Area2D in ovl:
		var body: = i.get_parent()
		if body is Player:
			return body
	return
