@tool
extends Node2D
class_name ScreenGuide

var vprect: Rect2

func _ready() -> void:
	set_notify_transform(true)
	if !Engine.is_editor_hint():
		visible = false

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		queue_redraw()

func _draw() -> void:
	var size: Vector2 = Vector2(
		ProjectSettings.get_setting("display/window/size/viewport_width"),
		ProjectSettings.get_setting("display/window/size/viewport_height")
	)
	vprect = Rect2(
		-size / 2.0,
		size
	)
	if visible:
		draw_rect(vprect, Color.WHITE, false)
		var from_x := Vector2(-vprect.position.x, 0.0)
		var to_x := Vector2(vprect.position.x, 0.0)
		var from_y := Vector2(0.0, -vprect.position.y)
		var to_y := Vector2(0.0, vprect.position.y)
		draw_line(from_x, to_x, Color.CYAN)
		draw_line(from_y, to_y, Color.CYAN)
		
		var points: Array[Vector2] = [
			Vector2(-1,-1),
			Vector2(1,1)
		]
		for i in points:
			var offset_x := -Vector2(i.x, 0.0) * vprect.position / 3.0
			var offset_y := -Vector2(0.0, i.y) * vprect.position / 3.0
			draw_line(from_x + offset_y, to_x + offset_y, Color.PURPLE)
			draw_line(from_y + offset_x, to_y + offset_x, Color.PURPLE)
