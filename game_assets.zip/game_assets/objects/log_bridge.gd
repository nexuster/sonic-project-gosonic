@tool
extends CharacterBody2D
class_name LogBridge
@onready var shape: CollisionShape2D = $CollisionShape2D

@export var bridge_texture: Texture2D
@export var length: int = 5

@export var debug_stand_log: int = 3
var stand_log: int = 3
var dip_angle: float = 90.0
var stand_entity: Player

var texture_rect := Rect2(0,0,16,16)
var texture_rect2 := Rect2(16,0,16,16)

func _process(delta: float) -> void:
	queue_redraw()
	shape.shape.size = Vector2(length * 16,16)
	shape.position = Vector2(length * 8, 0)
	if !Engine.is_editor_hint():
		if stand_entity and (
			!stand_entity.bridge_checker.is_colliding()
			or stand_entity.global_position.x < 0.0 + global_position.x
			or stand_entity.global_position.x > length * 16.0 + global_position.x):
			stand_entity = null
		if stand_entity:
			var relative = abs(stand_entity.global_position.x - global_position.x)
			var stand: int = floor(relative / 16.0) + 1
			
			stand = clampi(stand, 1, length)
			stand_log = stand
			dip_angle = 90
		else:
			dip_angle = move_toward(dip_angle, 0, 5.625)
		
		#position.y -= 1
		
	#debug_stand_log = clamp(debug_stand_log, 1, length)
	#stand_log = clamp(stand_log, 1, length)

func _draw() -> void:
	if Engine.is_editor_hint():
		stand_log = debug_stand_log
	var md = max_dip()
	for i in range(length):
		var rect: = Rect2(Vector2(i*16,0),texture_rect.size)
		
		var diff: float = abs((i + 1) - stand_log)
		var dist: float = 0
		if i + 1 < stand_log:
			dist = 1.0 - (diff / float(stand_log))
		else:
			dist = 1.0 - (diff / float(length - stand_log + 1)) 
		
		dist = clamp(dist, 0.0, 1.0)
			
		var v1 = md[stand_log-1] * sin(deg_to_rad(dip_angle))
		var v2 = sin(deg_to_rad(dist * 90))
		var v3 = min(v1 * v2, max_dip()[i])
		rect.position.y = round(v3)
		if i == stand_log - 1:
			shape.position.y = rect.position.y + floor(
				shape.shape.get_rect().size.y / 2.0
		)
		
		draw_texture_rect_region(
			bridge_texture, rect, texture_rect2
		)
	draw_texture_rect_region(
		bridge_texture,
		Rect2(
			Vector2(-16,-16),texture_rect.size
		),
		texture_rect
	)
	draw_texture_rect_region(
		bridge_texture,
		Rect2(
			Vector2((length)*16,-16),texture_rect.size
		),
		texture_rect
	)

func max_dip() -> Array:
	var result: Array
	
	var l = range(length)
	for i in l:
		var add: int = 0
		if i < length / 2.0:
			add = i*2
		else:
			add = ((i*-2) + (length * 2)) - 2
		result.append(add)
	
	return result

func distance(x: float,y: float) -> float:
	return abs(x - y)

func array_tostr(arr: Array) -> String:
	var s = ""
	for i in arr:
		s += String(i)
	return s
