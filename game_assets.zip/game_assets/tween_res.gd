extends Resource
class_name TweenResource

@export var easing: Tween.EaseType
@export var transition: Tween.TransitionType
@export var duration: float
