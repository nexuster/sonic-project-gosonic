extends Node2D
@export var enabled = true

func _ready():
	visible = !enabled
