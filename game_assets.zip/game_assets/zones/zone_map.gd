@tool
extends Node2D
class_name ZoneMap

@export var boundaries: ReferenceRect
@export var next_map_marker: Marker2D
@export var default_spawn: Marker2D

@export var sonic_texture: Texture2D

func _get_limits(offset: Vector2 = Vector2.ZERO) -> CameraLimits:
	var limits: CameraLimits = CameraLimits.new()
	var bound_rect: Rect2 = boundaries.get_rect()
	limits.set_rect(bound_rect, offset)
	return limits

func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint():
		queue_redraw()

func _draw() -> void:
	if Engine.is_editor_hint():
		var rect := Rect2(default_spawn.position - Vector2.ONE * 32, Vector2.ONE * 64)
		var src_rect := Rect2(Vector2.ZERO, Vector2.ONE * 64)
		draw_texture_rect_region(sonic_texture, rect, src_rect)
