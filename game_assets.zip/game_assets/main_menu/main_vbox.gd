@tool
extends VBoxContainer

func _ready() -> void:
	set_notify_transform(true)
	set_notify_local_transform(true)

func _notification(what: int) -> void:
	if what == 2000 or what == 35:
		get_parent().update_buttons()
