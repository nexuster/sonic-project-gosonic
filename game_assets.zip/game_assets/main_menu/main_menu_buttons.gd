@tool
extends Control
@onready var main: VBoxContainer = $side_menu/main
@onready var test_checkbox: CheckBox = $settings/VBoxContainer/delay_cam/CheckBox


const COLLUMN_DIVE = preload("uid://c3utwjxjkthqd")

@export var preview: bool = false
@export var preview_button: Button

@export var screen_previews: Dictionary[String, PackedScene]
@export var play_button: Button

@export var offset: Vector2
var started = false

func _ready() -> void:
	MusicManager.play_music(COLLUMN_DIVE)
	UI.fade_out()
	#offset = position
	if play_button:
		play_button.grab_focus()
		play_button.pressed.connect(_start_game)
	update_buttons()

func _process(_delta: float) -> void:
	if (!preview and Engine.is_editor_hint()):
		return
	var focused: Button
	for button: Button in main.get_children():
		if button.has_focus():
			focused = button
			break
	if !focused:
		focused = preview_button
	if focused:
		var _target_position: Vector2 = (
			-focused.position - Vector2(
				focused.offset_transform_position.x,
				focused.offset_transform_position.y
			)
		) + offset
		main.position += (
			_target_position-main.position
		) / 12.0

func update_buttons():
	var i: int = 0
	for button: Button in main.get_children():
		button.offset_transform_position.x = i * 32
		i += 1

func _start_game():
	if started:
		return
	started = true
	GoData.game_settings[&"delay_cam"] = test_checkbox.button_pressed
	
	UI.fade_in()
	MusicManager.fade_out(2.0)
	
	await get_tree().create_timer(2.0).timeout
	
	ScoreManager.reset_score(true, true, true, true)
	ScoreManager.time_stopped = false
	LoadingScreen.load_scene(self, "res://game_assets/zones/II/iizone.tscn")
